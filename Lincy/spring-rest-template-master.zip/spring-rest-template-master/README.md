# spring-rest-template
Spring REST Template Demo Project

REST Template demo project to show how to make requests with it. 

With lots of alternative ways to make requests, REST Template is a good option for making HTTP requests in any Java application.

Source Code for http://udemy.com/learn-spring-and-spring-boot-10x-productive-java-development/
