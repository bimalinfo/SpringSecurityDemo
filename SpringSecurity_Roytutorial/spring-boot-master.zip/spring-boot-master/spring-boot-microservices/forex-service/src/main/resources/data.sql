insert into forex_value(from_curr,to_curr,rate)
values('USD','INR',71);
insert into forex_value(from_curr,to_curr,rate)
values('EUR','INR',85);
insert into forex_value(from_curr,to_curr,rate)
values('AUD','INR',39);