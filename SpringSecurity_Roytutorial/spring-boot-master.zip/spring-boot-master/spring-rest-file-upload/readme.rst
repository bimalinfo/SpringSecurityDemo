You can read tutorial https://www.jeejava.com/file-upload-example-using-spring-rest-controller/
