You can read tutorial https://www.jeejava.com/angular-spring-boot-file-upload-example/
