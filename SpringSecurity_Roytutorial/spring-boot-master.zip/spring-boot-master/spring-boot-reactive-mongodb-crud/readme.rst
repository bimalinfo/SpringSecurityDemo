You can go through the tutorial https://www.jeejava.com/spring-boot-mongodb-functional-reactive-crud-example
