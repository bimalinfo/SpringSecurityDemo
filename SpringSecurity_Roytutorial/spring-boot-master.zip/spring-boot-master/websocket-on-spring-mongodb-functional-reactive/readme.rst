You can go through the tutorial https://www.jeejava.com/websocket-on-spring-mongodb-reactive-programming
