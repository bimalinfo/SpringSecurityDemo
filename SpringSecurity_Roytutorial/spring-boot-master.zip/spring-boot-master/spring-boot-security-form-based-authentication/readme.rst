You can go through the tutorial https://www.jeejava.com/spring-boot-security-form-based-authentication/
