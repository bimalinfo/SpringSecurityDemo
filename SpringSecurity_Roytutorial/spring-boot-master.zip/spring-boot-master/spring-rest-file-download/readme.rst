You can read tutorial https://www.jeejava.com/file-download-example-using-spring-rest-controller/
